package com.example.currencyconverter

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinnerFrom: Spinner = findViewById(R.id.spinner_from_currency)
        val spinnerTo: Spinner = findViewById(R.id.spinner_to_currency)
        val editTextAmount: EditText = findViewById(R.id.edittext_amount)
        val buttonConvert: Button = findViewById(R.id.button_convert)
        val textViewResult: TextView = findViewById(R.id.textview_result)

        val currencies = arrayOf("CAD", "USD", "EUR", "GBP", "INR")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        spinnerFrom.adapter = adapter
        spinnerTo.adapter = adapter

        buttonConvert.setOnClickListener {
            val amount = editTextAmount.text.toString().toDoubleOrNull()
            if (amount != null) {
                val fromCurrency = spinnerFrom.selectedItem.toString()
                val toCurrency = spinnerTo.selectedItem.toString()

                // Simple conversion logic (placeholder)
                val conversionRate = getConversionRate(fromCurrency, toCurrency)
                val convertedAmount = amount * conversionRate

                textViewResult.text = "$amount $fromCurrency = $convertedAmount $toCurrency"
            } else {
                textViewResult.text = "Please enter a valid amount"
            }
        }
    }

    private fun getConversionRate(fromCurrency: String, toCurrency: String): Double {
        // Placeholder conversion rates
        return when (fromCurrency) {
            "CAD" -> when (toCurrency) {
                "USD" -> 0.75
                "EUR" -> 0.67
                "GBP" -> 0.58
                "INR" -> 55.0
                "CAD" -> 1.0
                else -> 1.0
            }
            "USD" -> when (toCurrency) {
                "CAD" -> 1.33
                "EUR" -> 0.85
                "GBP" -> 0.75
                "INR" -> 74.0
                "USD" -> 1.0
                else -> 1.0
            }
            "EUR" -> when (toCurrency) {
                "CAD" -> 1.50
                "USD" -> 1.18
                "GBP" -> 0.88
                "INR" -> 87.0
                "EUR" -> 1.0
                else -> 1.0
            }
            "GBP" -> when (toCurrency) {
                "CAD" -> 1.72
                "USD" -> 1.34
                "EUR" -> 1.14
                "INR" -> 99.0
                "GBP" -> 1.0
                else -> 1.0
            }
            "INR" -> when (toCurrency) {
                "CAD" -> 0.018
                "USD" -> 0.014
                "EUR" -> 0.012
                "GBP" -> 0.010
                "INR" -> 1.0
                else -> 1.0
            }
            else -> 1.0
        }
    }
}
